package drum

import (
	"bytes"
	"encoding/binary"
	"errors"
	"math"
)

// The binary Pattern is the internal binary representation of the contents of a splice file
type binaryPattern struct {
	spliceName     []byte     //splice header which shoul be "SPLICE"
	overallPayload []byte     //indicates how much splice content to expect
	version        []byte     //version of the machine used to generate this file
	tempo          []byte     //a float indicating what speed to playback the audio sample
	tracks         []byte     //a dump of the section containing all the tracks
	groupedTracks  [][][]byte //splice of tracks - each track is a splice of measures - each measure has some byte splices
	sanitised      bool       //indicates if sanity checks have been carried out on the binary pattern
}

// The sanitize function checks headers and file sizes as well as groups bytes into measures.
// It returns all possible errors and warnings which may have been found in the binaryPattern
func (raw *binaryPattern) sanitize() (errs []error, warnings []error) {
	//is spliceName == "Splice"
	if !bytes.Equal(raw.spliceName, []byte{'S', 'P', 'L', 'I', 'C', 'E'}) {
		errs = append(errs, errors.New("splice header is invalid"))
	}

	//does overall payload tally?-> if too long truncate tracks. if too little, abort
	if checksum := (len(raw.tracks) + 36) - int(binary.BigEndian.Uint64(raw.overallPayload)); checksum != 0 {
		if checksum < 0 {
			errs = append(errs, errors.New("incomplete data in file"))
		}
		if checksum > 0 {
			raw.tracks = raw.tracks[:checksum]
			warnings = append(warnings, errors.New("file was truncated"))
		}

	}

	//break measuresDump into groups of tracks still in binary format
	tr := make([][]byte, 4)
	trNameLength := 0
	i := 0
	for i < len(raw.tracks) {
		//make space for a new track still in binary format
		tr = [][]byte{}
		//entry1 of a track is the 1 byte ID
		tr = append(tr, []byte{raw.tracks[i]})

		//The next 4 bytes are payload which tells us how long the track name is - it is not saved as part of the raw track
		trNameLength = int(binary.BigEndian.Uint32(raw.tracks[i+1 : i+5]))

		//entry2 of a track is the #entry2 bytes forming the name of the track
		tr = append(tr, raw.tracks[i+5:i+5+trNameLength])

		//entry3 is the 16bytes which represent the steps in the track
		tr = append(tr, raw.tracks[i+5+trNameLength:i+5+trNameLength+16])

		//add the new track to the group of tracks
		raw.groupedTracks = append(raw.groupedTracks, tr)

		//move on to where we believe the next track is to be found
		i = i + 5 + trNameLength + 16
	}

	//indicate sanity
	raw.sanitised = true

	//all done
	return errs, warnings
}

// The decode function takes our internal representation of the binary pattern
// and turns it into a human readable pattern
func (raw *binaryPattern) decode() (*Pattern, error) {

	if !raw.sanitised {
		return nil, errors.New("raw not sanitised")
	}

	//create a new pattern
	decodedSplice := &Pattern{}
	//indicate that it has not yet been decoded; just in case something goes wrong
	decodedSplice.decoded = false

	//decode the version
	n := bytes.Index(raw.version, []byte{0})
	decodedSplice.version = string(raw.version[:n])

	//decode the tempo
	decodedSplice.tempo = math.Float32frombits(binary.LittleEndian.Uint32(raw.tempo))

	//decode the tracks. 1 track at a time
	//each binary track representation has 3 entries
	//1. the track ID
	//2. the track name
	//3. the track steps
	//once all 3 have been identified: add the decoded track to the decoding object
	tr := track{}

	for _, rawTrack := range raw.groupedTracks {
		tr.id = uint(rawTrack[0][0])
		tr.name = string(rawTrack[1])
		copy(tr.measure[:], rawTrack[2])
		decodedSplice.tracks = append(decodedSplice.tracks, tr)
	}

	//all done - indicated decoding complete
	decodedSplice.decoded = true

	return decodedSplice, nil
}
