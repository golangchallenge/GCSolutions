// Package drum implements a decoder for splice files
package drum

import (
	"errors"
	"io"
	"io/ioutil"
	"log"
)

// DecodeFile decodes the drum machine file (splice file) found at the provided path
// and returns a pointer to a parsed pattern which is the entry point to the
// rest of the data.
func DecodeFile(path string) (*Pattern, error) {

	//read file
	raw, err := loadSpliceFile(path)
	if err != nil {
		return nil, err
	}

	//print pattern
	return raw.decode()
}

// loadSpliceFile reads data from the provided splice file
// and returns a binary representation of the drum machine it is assumed to contain
func loadSpliceFile(path string) (*binaryPattern, error) {
	//load all data
	rawData, err := ioutil.ReadFile(path)

	//is the data from the file ok?
	if err != nil {
		return nil, err
	}
	if len(rawData) < 51 {
		return nil, io.ErrUnexpectedEOF
	}

	//split raw data stream into different sections
	raw := &binaryPattern{}
	raw.spliceName = rawData[0:6]
	raw.overallPayload = rawData[6:14]
	raw.version = rawData[14:46]
	raw.tempo = rawData[46:50]
	raw.tracks = rawData[50:]
	raw.sanitised = false

	//sanitize entry
	errs, warnings := raw.sanitize()

	//handle errors and warnings from sanitisation
	if len(errs) != 0 {
		for _, err = range errs {
			log.Printf("Error in %v: %v", path, err)
		}
		err = errors.New("splice file is invalid")
	}
	if len(warnings) != 0 {
		for _, warning := range warnings {
			log.Printf("Warning in %v: %v", path, warning)
		}
	}

	return raw, err
}
