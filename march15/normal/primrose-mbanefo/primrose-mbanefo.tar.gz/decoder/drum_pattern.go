package drum

import "fmt"

// Pattern is the high level representation of the
// drum pattern contained in a .splice file.
type Pattern struct {
	version string
	tempo   float32
	tracks  []track
	decoded bool
}

// Prints a pattern out into something human readable
func (decodedDrum *Pattern) String() string {
	if !decodedDrum.decoded {
		return ("Input was not decoded properly")
	}

	versionString := fmt.Sprintf("Saved with HW Version: %v\n", decodedDrum.version)
	tempoString := fmt.Sprintf("Tempo: %v\n", decodedDrum.tempo)

	trackString := ""
	for _, tr := range decodedDrum.tracks {
		trackString = fmt.Sprintf("%v(%v) %v\t%v\n",
			trackString,
			tr.id,
			tr.name,
			tr.decodeMeasure())
	}
	return fmt.Sprintf("%v%v%v", versionString, tempoString, trackString)
}

//track is the high level representation of an audio track
//its principal components is a measure which has 16 steps
//it also has an id and a name
type track struct {
	id      uint
	name    string
	measure [16]byte
}

func (tr track) decodeMeasure() string {
	res := ""

	for i, step := range tr.measure {
		if i%4 == 0 {
			res = fmt.Sprintf("%v|", res)
		}
		if uint(step) == 1 {
			res = fmt.Sprintf("%vx", res)
		}
		if uint(step) == 0 {
			res = fmt.Sprintf("%v-", res)
		}
	}
	res = fmt.Sprintf("%v|", res)
	return res
}
