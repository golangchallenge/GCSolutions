package drum

import (
	"bytes"
	"errors"
	"encoding/binary"
	"fmt"
	"io"
	"os"
)

// DecodeFile decodes the drum machine file found at the provided path
// and returns a pointer to a parsed pattern which is the entry point to the
// rest of the data.
func DecodeFile(path string) (*Pattern, error) {
	p := &Pattern{}

	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}

	var magic [6]byte 
	if _, err := io.ReadFull(file, magic[:]); err != nil {
		return nil, err
	}
	if string(magic[:]) != "SPLICE" {
		return nil, errors.New("invalid file format")
	}

	var remaining int64
	if err := binary.Read(file, binary.BigEndian, &remaining); err != nil {
		return nil, err
	}

	const versionLen = 32
	var version [versionLen]byte
	if _, err := io.ReadFull(file, version[:]); err != nil {
		return nil, err
	}
	remaining -= versionLen
	i := bytes.IndexByte(version[:], 0)
	if i < 0 {
		i = versionLen
	}
	p.version = string(version[:i])

	if err := binary.Read(file, binary.LittleEndian, &p.tempo); err != nil {
		return nil, err
	}
	remaining -= 4 // sizeof(float32)

	for remaining > 0 {
		t := &Track{}

		if err := binary.Read(file, binary.BigEndian, &t.id); err != nil {
			return nil, err
		}
		remaining -= 1 // t.id == 1byte

		var trackLen int32
		if err := binary.Read(file, binary.BigEndian, &trackLen); err != nil {
			return nil, err
		}
		remaining -= 4 // 32bit integer

		track := make([]byte, trackLen)
		if _, err := io.ReadFull(file, track[:]); err != nil {
			return nil, err
		}
		t.name = string(track[:])
		remaining -= int64(trackLen)

		if _, err := io.ReadFull(file, t.ticks[:]); err != nil {
			return nil, err
		}
		remaining -= int64(len(t.ticks))

		p.tracks = append(p.tracks, *t)
	}

	return p, nil
}

// Track representats a single track within a pattern.
type Track struct {
	id    byte
	name  string
	ticks [16]byte
}

// Pattern is the high level representation of the
// drum pattern contained in a .splice file.
type Pattern struct {
	version string
	tempo   float32

	tracks []Track
}

func (p *Pattern) String() string {
	var b bytes.Buffer
	fmt.Fprintf(&b, "Saved with HW Version: %s\nTempo: %v\n", p.version, p.tempo)
	for _, track := range p.tracks {
		fmt.Fprintf(&b, "(%d) %s\t|", track.id, track.name)
		for idx, tick := range track.ticks {
			if tick > 0 {
				fmt.Fprint(&b, "x")
			} else {
				fmt.Fprint(&b, "-")
			}
			if idx%4 == 3 {
				fmt.Fprintf(&b, "|")
			}
		}
		fmt.Fprintln(&b)
	}

	return b.String()
}
