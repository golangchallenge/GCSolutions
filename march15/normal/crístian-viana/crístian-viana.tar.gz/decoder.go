package drum

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"os"
	"strings"
)

// MagicNumber is the first bytes of every .splice file.
const MagicNumber = "SPLICE"

// ErrInvalidMagicNumber is an error returned when the .splice file doesn't
// begin with MagicNumber.
var ErrInvalidMagicNumber = errors.New("invalid magic number")

// Pattern is the high level representation of the
// drum pattern contained in a .splice file.
type Pattern struct {
	Version [32]byte
	Tempo   float32
	Tracks  []Track
}

// Track is the representation of a sound track.
type Track struct {
	ID    uint8
	Name  []byte
	Steps [16]int8
}

// DecodeFile decodes the drum machine file found at the provided path
// and returns a pointer to a parsed pattern which is the entry point to the
// rest of the data.
func DecodeFile(path string) (*Pattern, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	magic := make([]byte, len(MagicNumber))

	if err = binary.Read(file, binary.BigEndian, &magic); err != nil {
		return nil, err
	}

	if string(magic) != MagicNumber {
		return nil, ErrInvalidMagicNumber
	}

	var dataLen uint64

	if err = binary.Read(file, binary.BigEndian, &dataLen); err != nil {
		return nil, err
	}

	var p Pattern

	if err = binary.Read(file, binary.BigEndian, &p.Version); err != nil {
		return nil, err
	}
	dataLen -= uint64(binary.Size(p.Version))

	if err = binary.Read(file, binary.LittleEndian, &p.Tempo); err != nil {
		return nil, err
	}
	dataLen -= uint64(binary.Size(p.Tempo))

	for dataLen > 0 {
		var t Track

		if err = binary.Read(file, binary.BigEndian, &t.ID); err != nil {
			return nil, err
		}
		dataLen -= uint64(binary.Size(t.ID))

		var trackNameLen uint32

		if err = binary.Read(file, binary.BigEndian, &trackNameLen); err != nil {
			return nil, err
		}
		dataLen -= uint64(binary.Size(trackNameLen))

		t.Name = make([]byte, trackNameLen)

		if err = binary.Read(file, binary.BigEndian, &t.Name); err != nil {
			return nil, err
		}
		dataLen -= uint64(binary.Size(t.Name))

		if err = binary.Read(file, binary.BigEndian, &t.Steps); err != nil {
			return nil, err
		}
		dataLen -= uint64(binary.Size(t.Steps))

		p.Tracks = append(p.Tracks, t)
	}

	return &p, nil
}

// String returns a string representation of a Pattern.
func (p Pattern) String() string {
	var str bytes.Buffer

	trimmedVersion := strings.TrimRight(string(p.Version[:]), "\x00")
	str.WriteString(fmt.Sprintf("Saved with HW Version: %s\nTempo: %v\n", trimmedVersion, p.Tempo))

	for _, t := range p.Tracks {
		str.WriteString(fmt.Sprintf("(%d) %s\t", t.ID, t.Name))

		for i, s := range t.Steps {
			if i%4 == 0 {
				str.WriteRune('|')
			}

			if s == 0 {
				str.WriteRune('-')
			} else {
				str.WriteRune('x')
			}
		}

		str.WriteString("|\n")
	}

	return str.String()
}
